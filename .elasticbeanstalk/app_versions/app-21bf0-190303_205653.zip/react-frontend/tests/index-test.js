var assert = require('assert');
describe('Array', function() {
    it('Should run the tests successfully.', function() {
      assert.equal([1, 2, 3].indexOf(4), -1);
    });
  });
